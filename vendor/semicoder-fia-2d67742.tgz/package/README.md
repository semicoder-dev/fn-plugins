# @semicoder/fia

FIA 4 creates macOS 14+ Apple Silicon apps for humans and agents with one typed API, React UI, bundled CLI, TypeScript script SDK and agent skill. React, Vite, Bun and the precompiled Swift host remain the runtime architecture.

```bash
fia create my-app
cd my-app
bun run dev
bun run build
```

There is one project template. `create` accepts `--yes`, `--git/--no-git`, `--install/--no-install` and `--local`. It never asks for a backend or native mode. `--local` installs the current FIA package directory; precompiled assets must already exist.

## Commands

| Command                               | Purpose                                                    |
| ------------------------------------- | ---------------------------------------------------------- |
| `agent [--preview] <args>`            | Invoke this project’s development or preview application   |
| `dev [--open-browser]`                | Native window, Vite HMR and supervised Bun restart         |
| `run`                                 | Build and launch an isolated Preview app without HMR       |
| `build`                               | Assemble and sign a local `.app` without Swift compilation |
| `build --dmg`                         | Create and mount-check a local test DMG                    |
| `release`                             | Developer ID signing, notarization, stapling and DMG       |
| `release --update`                    | Signed frontend/backend code release                       |
| `check` / `test`                      | Validate config and TypeScript / run application Bun tests |
| `doctor --target dev\|release --json` | Check runtime assets, OS and publishing tools              |
| `status` / `logs` / `stop`            | Inspect or stop this project's development session         |
| `smoke --json`                        | Production launch, frontend readiness and orderly shutdown |
| `icon F`                              | Render a text icon using the precompiled host              |
| `update keygen --output <directory>`  | Generate an Ed25519 release key pair                       |

`icon` accepts `--background`, `--foreground`, `--output`, and `--force` for exported files. In a project it writes the configured app icon, or `assets/icon.icns`; the standard path is discovered automatically. It does not rewrite executable TypeScript configuration. Keep private update keys outside the repository.

`dev` produces `.fia/dev/<name> Dev.app` with a yellow DEV badge and a `.dev` macOS bundle ID. `run` produces `.fia/preview/<name> Preview.app` with a blue PREV badge and a `.preview` bundle ID. Menu bar labels distinguish both. Local modes disable release updates; `build` and `release` retain the configured production identity.

Development keeps its existing `.fia/dev/data/<identifier>` storage; Preview uses `.fia/preview/data/<identifier>`. The local bundle embeds its data root, including when opened directly; an explicit `FIA_DATA_DIRECTORY` still overrides it. Local bundles are project artifacts, not portable distributions. Production bundles use Application Support by default. The logical `app.identifier` and Keychain service stay stable, so applications should scope Keychain keys by `app.dataDirectory`. `app.mode` exposes development/preview/production for UI labels. Installed local CLI/skill names use `-dev` or `-preview`; `fia agent --preview quit` exits Preview.

## Configuration

```ts
import { defineConfig } from "@semicoder/fia/config";

export default defineConfig({
  app: { name: "My App", identifier: "com.example.my-app", version: "1.0.0", build: 1 },
  agent: { command: "my-app", description: "Describe what the application can do." },
  statusItem: { symbol: "terminal", tooltip: "My App" },
  signing: {
    releaseIdentity: "Developer ID Application: Example (TEAMID)",
    notarizationProfile: "my-notary-profile",
  },
  updates: {
    url: "https://downloads.example.com/my-app/latest.json",
    publicKey: "BASE64_RAW_ED25519_PUBLIC_KEY",
    downloadURL: "https://example.com/download",
  },
});
```

The minimal config needs `app` and `agent.command/description`. The shared API defaults to `shared/api.ts`; override with `api.entry`. `agent.instructions` can point to application-specific Markdown workflows. Optional backend settings are `entry` and `assets`; optional web settings are `root` and `dist`, which must match Vite's output. There are no enabled, mode, template or Swift settings.

Paths in `backend.assets` are relative to `context.app.codeDirectory`: the project root in development, and the packaged code directory in production. For example, `assets: ["assets/model.wasm"]` can be read with `Bun.file(context.app.codeDirectory + "/assets/model.wasm")`. Store writable user data in `context.app.dataDirectory`.

Unpublished co-development capability: `runtime: { assets: ["resources/runtime.tgz"] }` declares immutable files shipped only in a full application. Entries must be regular project files, with no symlink components, escaping paths, case collisions, or overlap with `backend.assets`. Read them relative to `context.app.runtimeDirectory`: the project root in development, or `Contents/Resources/runtime` in preview/production. Paths and the copied file contents contribute to `runtimeId`; changes require a full installation package. Code updates never copy these files and retain their existing restrictions. Applications without runtime assets keep the previous identity calculation.

## Publishing

Generate keys with `fia update keygen --output /secure/path/my-app-keys`, copy the public key into config, and create the first full installer with `fia release`. Configure the same update key before distributing that installer.

For a code update, increase `app.build` and `app.version`, keep the runtime settings unchanged, then run:

```bash
FIA_UPDATE_PRIVATE_KEY_FILE=/secure/path/my-app-keys/update-private.pem fia release --update
```

Upload `dist/updates/releases/<build>/` to the matching `releases/<build>/` directory beside your update URL, then publish `dist/updates/latest.json` at the configured URL. Upload the manifest last. Release directories are immutable; choose a new build number for another release. The CLI creates artifacts and does not upload them.

Both frontend and backend switch together after native confirmation. Native windows survive, but JS memory and connections restart. Persistent state belongs in backend `context.app.dataDirectory`. Keep data migrations compatible with the previous code version. Changes to the host, Bun, system permissions or native configuration need a new installer.

No Swift compiler is used by application create/dev/build/icon. Full installer releases still require the Apple signing and notarization tools and your own Developer ID credentials.

## Application CLI

Install the command explicitly from the application or tray menu (or `native.agent.installCLI()`). The default target is `~/.local/bin`; shell profiles are never modified. The application bundles its own Bun runtime. Move the app first, then reinstall the command to repair its path if necessary.

```bash
my-app schema --json
my-app call counter.increment --json '{"by":1}'
my-app events counter.changed --jsonl
my-app exec -e 'console.log(await app.call("counter.get", {}))'
my-app exec --file workflow.ts --timeout 60000
my-app skill install --dir ~/.agents/skills
my-app open
my-app status --json
my-app quit
```

Calls automatically start the app without presenting a window. `open` presents the existing instance. Scripts are trusted local code, not sandboxed; they run in a supervised Bun child process and finish with the CLI invocation. They may use already installed dependencies, but do not auto-install packages. Event reconnection requires refreshing state; failed writes are never automatically replayed.

The CLI launcher, command name and Bun are part of the immutable runtime. API handlers, schema, UI, skill and type definitions are a single signed code release. Active calls/scripts or an application `beforeUpdate` veto postpone activation. CLI calls return `updating` during the switch and observation period. Candidate skills remain unpublished until commit; rollback retains the previous skill.

See [FIA 4 migration](docs/framework/migration-v4.md) and [framework contract](docs/framework/README.md).

## Browser debugging and event waits

The local source provides full browser UI in development, preview and production. Every native web window includes an Open in Browser icon at the far right; `setTitlebar([])` preserves it. Use `fia dev --open-browser`, `fia agent [--preview] open --browser`, or the packaged application's `open --browser`. Only explicit `--url` prints a one-use, 60-second authorization link. Browser tabs share backend data, keep their own unsaved state, and retain authorization across refresh until backend restart/update or Disconnect Browser Sessions in the app/tray menu.

Browser sessions use independent, tab-scoped credentials and an authenticated Service Worker for resources; bare addresses grant no API access. Use `openWebSocket(path, protocols?)` from `@semicoder/fia/client` for business sockets. Browser native calls are allowlisted, with effective permissions exposed by `native.capabilities()`. See the framework contract for lifecycle and security details. Available starting with FIA 0.17.0. Upgrading an existing application requires a new complete application build because the native host changes.

```sh
my-app events session.changed --jsonl --count 1 --timeout 30000 \
  --match '{"sessionId":"session-1","status":"idle"}'
```

Matching uses top-level scalar equality (all fields must match). Count completion exits 0; timeout exits 124 without an error frame; cancellation exits 130. No count means unlimited events; no timeout or 0 means unlimited time. Subscribe before triggering work and read current state after waiting; events have no replay.

Shared API requests, responses and individual events each have a 1 MiB UTF-8 limit, including their envelope. Use pagination for histories and custom `defineBackend.http` routes for attachments or token streams. Routes are relative to `/api` and are not exposed by the application CLI. Background lifecycle hooks and routes receive typed `context.emit`. See the packaged [framework documentation](docs/framework/README.md) for background tasks, JSON diagnostics and WebSocket option sharing.

## 应用自定义 CLI 子命令

在 `fia.config.ts` 的 `agent.commands` 中声明子命令，例如 `commands: { plugin: { description: "Develop plugins", entry: "cli/plugin.ts" } }`。命令名不能覆盖 help、call、exec 等框架内置命令。入口默认导出接收 `FIACommandContext`（从 `@semicoder/fia/config` 导入类型）的函数，返回 `void` 或 0–255 退出码。

上下文包含 `args`、调用者 `cwd` 和 `assetsDirectory`（开发项目根目录；生产生效代码的 backend 资产目录）。入口会被编译进签名代码产物，通过 `应用命令 plugin ...` 或 `fia agent plugin ...` 调用；help 与生成的 skill 自动列出它。命令跟随当前生效版本，沿用实例连接、后台启动、脚本租约和进程组清理，不创建另一套 CLI。自定义命令不设执行超时，Ctrl-C/应用断开会终止；运行期间阻止应用更新。stdout/stderr 和退出码原样传递，参数以数组传递。

自定义命令可要求自己的开发依赖；框架不会隐式安装依赖或执行包安装脚本。应用应在命令帮助中注明要求。变更通用 CLI 会改变 runtime ID，既有应用须通过完整安装包取得新运行时。

带自定义命令的开发应用在后端脚本或其项目依赖变化时重新构建，避免命令继续使用旧 bundle。原生 Keychain/对话框交互期间，监督层与外层启动流程共用就绪判定；开发 CLI 同样暂停等待计时，交互结束后恢复超时约束。

## Keep a window on top (0.18.0)

Native web windows include a pin icon to the left of Open in Browser. Click to toggle the current window between normal and floating levels; the filled, highlighted icon indicates that it is pinned. Pinning remains available while loading or reconnecting and survives titlebar updates and hiding/reopening the main window. It resets when the window is destroyed or the app quits. This does not pin browser windows or move windows across desktops/fullscreen spaces. New projects include it automatically; existing apps must rebuild and distribute the complete application with the new native host.

## 框架与首个应用共同开发（未发布）

FIA 活跃源码现位于麻辣烫仓库的 `framework/fia/`，保留独立 API、模板、测试与打包边界；麻辣烫稳定后再拆回独立仓库。公开 npm 0.18.0 不包含本次联调工具或 Bun 1.4.3 运行时。普通消费已发布 npm 包的应用仍不需要 Swift；维护共仓源码需要 Bun 1.4.3 和 Swift 6 工具链。框架维护流程保存在源码仓库的 `docs/co-development.md`，不作为应用依赖。

开发 CLI 新增可重复的 `fia dev --watch-ignore <相对目录>`，按目录边界排除指定子树，不影响相似前缀的其他目录。该参数仅供外层工具已经负责构建/重启的目录；默认生成应用无需设置。嵌套的 node_modules、.git、.fia、.build、dist 也不会触发后端重载。
